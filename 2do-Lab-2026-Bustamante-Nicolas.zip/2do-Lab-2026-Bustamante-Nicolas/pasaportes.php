<?php
session_start();




    $arregloPersonas = json_decode($_COOKIE["pasaporte"],true);

    echo "<h3>Cantidad de reportes generados: ".$_SESSION['cantidadGenerados']."</h3>";

    foreach ($arregloPersonas as $usuario) {

        echo "<h3>Nombre: ".$usuario['nombre']."</h3>";
        echo "<h3>Apellido: ".$usuario['apellido']."</h3>";
        echo "<h3>Documento: ".$usuario['documento']."</h3>";
        echo "<h3>Fecha de nacimiento: ".$usuario['fechaNacimiento']."</h3>";
        echo "<h3>Genero: ".$usuario['genero']."</h3>";
        echo "<h3>Pais: ".$usuario['pais']."</h3>";
        echo "<h3>Renueva: ".$usuario['renueva']."</h3>";
        echo "<h3>Fecha alta: ".$usuario['fechaAlta']."</h3>";
        echo "<h3>Codigo Verificador: ".$usuario['codigoVerificador']."</h3>";
      
        
    }

    
    echo "<a href='formularioPasaporte.php'>Volver</a>";


?>

